package clasesformato;

public abstract class Activo {
	private double cantidad;
	public abstract Double getStock();
	
	public double getCantidad() {
		return cantidad;
	}
}
