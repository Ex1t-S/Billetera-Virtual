/**
 * 
 */
/**
 * @author gerar
 *
 */
module Entregable {
	requires java.desktop;
	requires java.sql;
	requires java.net.http;
	requires org.json;
}